# horn-concerto
📯 Mining horn clauses in RDF datasets using SPARQL queries.
